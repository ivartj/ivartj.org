#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

int xpos = 0, ypos = 0;
int wdim = 80, hdim = 24;
char *dbpath = NULL;
char *inpath = NULL;
FILE *dbfile = NULL;

void usage(FILE *out)
{
	fprintf(out, "usage: dbq [ <x>,<y> ] [ <w>x<y> ] <database-file> [ <write-file> ]\n");
}

void parsearg(char *arg)
{
	int x, y;
	unsigned w, h;
	if(sscanf(arg, "%d,%d", &x, &y) == 2) {
		xpos = x;
		ypos = y;
		return;
	}
	if(sscanf(arg, "%ux%u", &w, &h) == 2) {
		wdim = w;
		hdim = h;
		return;
	}
	if(dbpath == NULL)
		dbpath = arg;
	else
		inpath = arg;
}

void parseargs(int argc, char *argv[])
{
	int c, i;
	static struct option longopts[] = {
		{ "help", no_argument, NULL, 'h' },
		{ 0, 0, 0, 0 },
	};

	while((c = getopt_long(argc, argv, "h", longopts, NULL)) != -1)
	switch(c) {
	case 'h':
		usage(stdout);
		exit(EXIT_SUCCESS);
	case ':':
	case '?':
		usage(stderr);
		exit(EXIT_FAILURE);
	}

	for(i = optind; i < argc; i++) {
		parsearg(argv[i]);
	}
}

int checkdb(void)
{
	int amode = R_OK;

	if(access(dbpath, F_OK))
		return 1;

	if(inpath != NULL)
		amode |= W_OK;

	if(access(dbpath, amode)) {
		perror("access");
		exit(EXIT_FAILURE);
	}

	return 0;
}

void createdb(void)
{
	dbfile = fopen(dbpath, "w+");
	if(dbfile == NULL) {
		perror("Failed to open database file");
		exit(EXIT_FAILURE);
	}
}

int main(int argc, char *argv[])
{
	parseargs(argc, argv);
	if(checkdb())
		createdb();
	else
		opendb();
	querydb();
	exit(EXIT_SUCCESS);
}
